<?php

return [
    'site_title' => 'Enfermería Estudiantes',
];
